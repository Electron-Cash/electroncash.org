from electroncash.i18n import _

fullname = _('Email')
description = _("Send payment requests via email")
available_for = ['qt']
